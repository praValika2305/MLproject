export function Container({ children }) {
  return <main className="main">{children}</main>;
}

export function Loader() {
  return <p className="loader">Loading...</p>;
}
